from flask import Flask, render_template, request, jsonify
import numpy as np
import tensorflow as tf
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences

app = Flask(__name__)

# Load trained model
model = tf.keras.models.load_model("LSTM_model.h5")

# Recreate tokenizer EXACTLY like training
def separate_punc(doc_text):
    return [token.lower() for token in doc_text.split(" ")
            if token not in '\n\n \n\n\n!"-#$%&()--.*+,-/:;<=>?@[\\]^_`{|}~\t\n ']

# Load dataset
with open("SampleDataset.txt", "r", encoding="utf-8") as f:
    data = f.read().lower()

data = separate_punc(data)
cleaned_data = " ".join(data)

# Create tokenizer
tokenizer = Tokenizer(num_words=None, char_level=False)
tokenizer.fit_on_texts([cleaned_data])

# IMPORTANT: Must match training max_len
MAX_LEN = 324


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/predict", methods=["POST"])
def predict():
    input_text = request.form["text"].lower()
    num_words = int(request.form["num_words"])

    generated_text = input_text

    for _ in range(num_words):
        token_text = tokenizer.texts_to_sequences([generated_text])[0]

        padded_token_text = pad_sequences(
            [token_text], maxlen=MAX_LEN, padding="pre"
        )

        predicted_probs = model.predict(padded_token_text, verbose=0)
        predicted_index = np.argmax(predicted_probs)

        output_word = ""

        for word, index in tokenizer.word_index.items():
            if index == predicted_index:
                output_word = word
                break

        if output_word == "":
            break

        generated_text += " " + output_word

    return jsonify({"result": generated_text})


if __name__ == "__main__":
    app.run(debug=True)